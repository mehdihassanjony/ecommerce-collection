var MediasDirectives = angular.module('aq.medias.directives', []);
