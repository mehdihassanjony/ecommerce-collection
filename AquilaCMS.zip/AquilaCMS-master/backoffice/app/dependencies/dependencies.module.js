var currModule = {name: "aq.dependencies"};

angular.module(currModule.name, []);