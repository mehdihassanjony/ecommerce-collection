var CmsBlocksDirectives = angular.module('aq.cmsBlocks.directives', []);
