var TerritoriesDirectives = angular.module('aq.territories.directives', []);
