var ShipmentFilters = angular.module('aq.shipment.filters', []);

