let ProductSimpleServices = angular.module('aq.simpleProduct.services', ['ngResource']);

ProductSimpleServices.service("ImportedProductImage", function () {
    return {component_template: ""};
});

ProductSimpleServices.service('HookProductInfo', function ()
{
    return [];
});