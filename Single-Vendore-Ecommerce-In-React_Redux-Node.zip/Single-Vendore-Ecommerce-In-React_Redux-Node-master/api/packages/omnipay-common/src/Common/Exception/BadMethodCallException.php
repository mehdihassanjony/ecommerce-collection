<?php

namespace Omnipay\Common\Exception;

/**
 * Bad Method Call Exception
 */
class BadMethodCallException extends \BadMethodCallException implements OmnipayException
{
}
