<?php 

echo 'shop layout';