<?php

include('./../app/Http/Core/View.php');

View::init();

View::content('auth.sync');
