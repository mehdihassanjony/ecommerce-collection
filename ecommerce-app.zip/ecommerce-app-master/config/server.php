<?php

/** SMTP Configurations */
date_default_timezone_set("Asia/Dhaka");

$GLOBALS['SMTPHOST'] = "mail.example.com";
$GLOBALS['SMTPUSER'] = "info@example.com";
$GLOBALS['SMTPPORT'] = "465";
$GLOBALS['SMTPAUTH'] = "ssl";
$GLOBALS['SMTPPASS'] = "";
