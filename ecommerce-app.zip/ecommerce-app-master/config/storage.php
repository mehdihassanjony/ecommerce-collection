<?php

/** Upload Storage */
$GLOBALS['upDir'] = [
	'admin'	=> 'storage/admins/',
	'user'	=> 'storage/users/',
	'subCat'	=> 'storage/sub-category/',
	'sliders'	=> 'storage/sliders/'
];
