				</div>
			</div>
			<footer class="footer">
				© 2018 Agroxa <span class="d-none d-sm-inline-block">- Crafted with <i class="mdi mdi-heart text-danger"></i> by eCommerce.</span>
			</footer>
		</div>
	</div>

	<script src="<?php echo asset('js/backend/bootstrap.bundle.min.js'); ?>"></script>
	<script src="<?php echo asset('js/backend/metisMenu.min.js'); ?>"></script>
	<script src="<?php echo asset('js/backend/jquery.slimscroll.js'); ?>"></script>
	<script src="<?php echo asset('js/backend/waves.min.js'); ?>"></script>

	<script src="<?php echo asset('plugins/datatable/js/jquery.dataTables.min.js'); ?>"></script>
	<script src="<?php echo asset('plugins/datatable/js/dataTables.bootstrap4.min.js'); ?>"></script>
	<script src="<?php echo asset('plugins/datatable/js/dataTables.buttons.min.js'); ?>"></script>
	<script src="<?php echo asset('plugins/datatable/js/buttons.bootstrap4.min.js'); ?>"></script>
	<script src="<?php echo asset('plugins/datatable/js/jszip.min.js'); ?>"></script>
	<script src="<?php echo asset('plugins/datatable/js/pdfmake.min.js'); ?>"></script>
	<script src="<?php echo asset('plugins/datatable/js/vfs_fonts.js'); ?>"></script>
	<script src="<?php echo asset('plugins/datatable/js/buttons.html5.min.js'); ?>"></script>
	<script src="<?php echo asset('plugins/datatable/js/buttons.print.min.js'); ?>"></script>
	<script src="<?php echo asset('plugins/datatable/js/buttons.colVis.min.js'); ?>"></script>
	<script src="<?php echo asset('plugins/datatable/js/dataTables.responsive.min.js'); ?>"></script>
	<script src="<?php echo asset('plugins/datatable/js/responsive.bootstrap4.min.js'); ?>"></script>

	<script src="<?php echo asset('plugins/peity/jquery.peity.min.js'); ?>"></script>
	<script src="<?php echo asset('js/backend/app.js', true); ?>"></script>
	<script src="<?php echo asset('js/backend/main.js'); ?>"></script>

	<script src="<?php echo asset('js/custom.js'); ?>"></script>

</body>

</html>
