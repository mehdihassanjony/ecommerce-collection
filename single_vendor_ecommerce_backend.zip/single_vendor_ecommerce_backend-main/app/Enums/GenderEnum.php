<?php

namespace App\Enums;

enum GenderEnum:string {
    case Male = 'male';
    case Female = 'female';
}
