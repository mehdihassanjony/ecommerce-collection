export default {
  addToCart: "Add to cart",
  quantity: "Quantity"
};
