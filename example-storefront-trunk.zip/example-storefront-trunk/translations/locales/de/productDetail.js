export default {
  addToCart: "Zum Warenkorb hinzufügen",
  quantity: "Menge"
};
