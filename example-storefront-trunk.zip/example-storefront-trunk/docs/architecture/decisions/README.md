# Architecture Decision Records

The following decisions are inherited from the Reaction Component Library:

- [5. Test Components](https://github.com/reactioncommerce/reaction-component-library/blob/master/docs/architecture/decisions/0005-test-components.md)
- [8. Keep Styles With Components](https://github.com/reactioncommerce/reaction-component-library/blob/master/docs/architecture/decisions/0008-keep-styles-with-components.md)
