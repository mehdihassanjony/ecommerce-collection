export { default } from "./ProductDetail";
