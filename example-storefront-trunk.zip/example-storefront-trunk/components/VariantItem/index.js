export { default } from "./VariantItem";
