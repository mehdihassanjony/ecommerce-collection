export { default } from "./ProductDetailDescription";
