export { default } from "./VariantList";
