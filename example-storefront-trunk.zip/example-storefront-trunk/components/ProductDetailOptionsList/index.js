export { default } from "./ProductDetailOptionsList";
