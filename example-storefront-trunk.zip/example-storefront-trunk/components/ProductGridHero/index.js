export { default } from "./ProductGridHero";
