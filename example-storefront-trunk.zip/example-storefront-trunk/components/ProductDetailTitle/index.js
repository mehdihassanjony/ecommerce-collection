export { default } from "./ProductDetailTitle";
