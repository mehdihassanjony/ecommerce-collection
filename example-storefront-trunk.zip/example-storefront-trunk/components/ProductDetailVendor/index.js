export { default } from "./ProductDetailVendor";
