export { default } from "./ProductDetailPrice";
