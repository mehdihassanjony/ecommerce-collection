## 9. Final checks

That's all.

If you:
1. Run cezerin2, cezerin2-store, cezerin2-admin apps.
2. Run webserver nginx with cezerin config.
3. Setup DNS records.

You will see working store in your browser by this urls:

Store: https://your-domain-name.com

API: https://your-domain-name.com/api/v1/settings

Dashboard: https://admin.your-domain-name.com

