/* eslint-disable camelcase */
export const server_url = 'https://ecommero.ninjascode.com/'
export const ws_server_url = 'wss://ecommero.ninjascode.com/'
export const cloudinary_upload_url =
  'https://api.cloudinary.com/v1_1/ecommero/image/upload'
export const cloudinary_sub_categories = 'd11htdsp'
export const cloudinary_products = 'cb9rpz8r'
