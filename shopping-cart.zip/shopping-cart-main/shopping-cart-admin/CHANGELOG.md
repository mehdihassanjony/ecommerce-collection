## [1.0.0] 2019-03-13
### Original Release
- Added Reactstrap as base framework
- Added design from Argon Dashboard by Creative Tim
