// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'date_formatter.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$dateFormatterHash() => r'acbf69f0d7e40c9df37b54b28eeec5dbb982a723';

/// See also [dateFormatter].
@ProviderFor(dateFormatter)
final dateFormatterProvider = AutoDisposeProvider<DateFormat>.internal(
  dateFormatter,
  name: r'dateFormatterProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$dateFormatterHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef DateFormatterRef = AutoDisposeProviderRef<DateFormat>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
