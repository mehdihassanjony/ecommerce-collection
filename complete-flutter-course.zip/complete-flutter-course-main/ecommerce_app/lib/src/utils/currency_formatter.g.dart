// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'currency_formatter.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$currencyFormatterHash() => r'd62e64f3963ad26588fa58656b90a06f54abfd32';

/// See also [currencyFormatter].
@ProviderFor(currencyFormatter)
final currencyFormatterProvider = AutoDisposeProvider<NumberFormat>.internal(
  currencyFormatter,
  name: r'currencyFormatterProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$currencyFormatterHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef CurrencyFormatterRef = AutoDisposeProviderRef<NumberFormat>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
