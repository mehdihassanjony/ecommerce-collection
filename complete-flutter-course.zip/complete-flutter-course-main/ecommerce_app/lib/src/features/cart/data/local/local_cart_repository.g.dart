// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'local_cart_repository.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$localCartRepositoryHash() =>
    r'e13ac4190cf19fa3f638b583d346d5145c6f6a1e';

/// See also [localCartRepository].
@ProviderFor(localCartRepository)
final localCartRepositoryProvider = Provider<LocalCartRepository>.internal(
  localCartRepository,
  name: r'localCartRepositoryProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$localCartRepositoryHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef LocalCartRepositoryRef = ProviderRef<LocalCartRepository>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
