// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'remote_cart_repository.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$remoteCartRepositoryHash() =>
    r'2284e4e23b2a40cd5ae1af5928686e983ecd4512';

/// See also [remoteCartRepository].
@ProviderFor(remoteCartRepository)
final remoteCartRepositoryProvider = Provider<RemoteCartRepository>.internal(
  remoteCartRepository,
  name: r'remoteCartRepositoryProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$remoteCartRepositoryHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef RemoteCartRepositoryRef = ProviderRef<RemoteCartRepository>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
