// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'shopping_cart_screen_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$shoppingCartScreenControllerHash() =>
    r'8123dd3aaf0bf02858cb11556ecba6c16b72aedd';

/// See also [ShoppingCartScreenController].
@ProviderFor(ShoppingCartScreenController)
final shoppingCartScreenControllerProvider = AutoDisposeAsyncNotifierProvider<
    ShoppingCartScreenController, void>.internal(
  ShoppingCartScreenController.new,
  name: r'shoppingCartScreenControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$shoppingCartScreenControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$ShoppingCartScreenController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
