// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'add_to_cart_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$addToCartControllerHash() =>
    r'0238f81034cce3512a17fc50b91aba81ff5ac664';

/// See also [AddToCartController].
@ProviderFor(AddToCartController)
final addToCartControllerProvider =
    AutoDisposeAsyncNotifierProvider<AddToCartController, int>.internal(
  AddToCartController.new,
  name: r'addToCartControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$addToCartControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AddToCartController = AutoDisposeAsyncNotifier<int>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
