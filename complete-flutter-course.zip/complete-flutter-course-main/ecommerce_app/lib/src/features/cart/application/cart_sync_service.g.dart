// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cart_sync_service.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$cartSyncServiceHash() => r'3ad28e876fb58d96ae4b4aa09f8f494e6940de94';

/// See also [cartSyncService].
@ProviderFor(cartSyncService)
final cartSyncServiceProvider = Provider<CartSyncService>.internal(
  cartSyncService,
  name: r'cartSyncServiceProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$cartSyncServiceHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef CartSyncServiceRef = ProviderRef<CartSyncService>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
