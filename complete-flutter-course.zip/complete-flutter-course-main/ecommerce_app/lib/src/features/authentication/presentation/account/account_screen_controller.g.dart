// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'account_screen_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$accountScreenControllerHash() =>
    r'214c588739a1c695e32a9a386805299d46a9625a';

/// See also [AccountScreenController].
@ProviderFor(AccountScreenController)
final accountScreenControllerProvider =
    AutoDisposeAsyncNotifierProvider<AccountScreenController, void>.internal(
  AccountScreenController.new,
  name: r'accountScreenControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$accountScreenControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AccountScreenController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
