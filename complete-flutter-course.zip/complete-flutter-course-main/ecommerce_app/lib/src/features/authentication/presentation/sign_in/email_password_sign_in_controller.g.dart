// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'email_password_sign_in_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$emailPasswordSignInControllerHash() =>
    r'9297287fca9087a9a6e5d554d6136e07b3f0cea0';

/// See also [EmailPasswordSignInController].
@ProviderFor(EmailPasswordSignInController)
final emailPasswordSignInControllerProvider = AutoDisposeAsyncNotifierProvider<
    EmailPasswordSignInController, void>.internal(
  EmailPasswordSignInController.new,
  name: r'emailPasswordSignInControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$emailPasswordSignInControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$EmailPasswordSignInController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
