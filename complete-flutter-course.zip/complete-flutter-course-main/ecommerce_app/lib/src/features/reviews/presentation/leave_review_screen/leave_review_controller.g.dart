// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'leave_review_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$leaveReviewControllerHash() =>
    r'5f71662fcc7a950a82967bb17abc735d3793b180';

/// See also [LeaveReviewController].
@ProviderFor(LeaveReviewController)
final leaveReviewControllerProvider =
    AutoDisposeAsyncNotifierProvider<LeaveReviewController, void>.internal(
  LeaveReviewController.new,
  name: r'leaveReviewControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$leaveReviewControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$LeaveReviewController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
