// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'fake_checkout_service.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$checkoutServiceHash() => r'3ede6113d124c0a83c8517175d0f90cb8ae34fd4';

/// See also [checkoutService].
@ProviderFor(checkoutService)
final checkoutServiceProvider =
    AutoDisposeProvider<FakeCheckoutService>.internal(
  checkoutService,
  name: r'checkoutServiceProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$checkoutServiceHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef CheckoutServiceRef = AutoDisposeProviderRef<FakeCheckoutService>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
