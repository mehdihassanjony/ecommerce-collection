// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'payment_button_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$paymentButtonControllerHash() =>
    r'32af9b54f0a19136e29fc2e868b1bf9e903976e8';

/// See also [PaymentButtonController].
@ProviderFor(PaymentButtonController)
final paymentButtonControllerProvider =
    AutoDisposeAsyncNotifierProvider<PaymentButtonController, void>.internal(
  PaymentButtonController.new,
  name: r'paymentButtonControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$paymentButtonControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$PaymentButtonController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
