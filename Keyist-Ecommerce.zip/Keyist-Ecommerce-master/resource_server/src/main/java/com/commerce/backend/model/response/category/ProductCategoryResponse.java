package com.commerce.backend.model.response.category;

import com.commerce.backend.model.dto.CategoryDTO;
import lombok.Data;

@Data
public class ProductCategoryResponse {
    private CategoryDTO category;
}