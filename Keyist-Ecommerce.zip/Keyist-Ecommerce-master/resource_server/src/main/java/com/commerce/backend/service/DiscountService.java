package com.commerce.backend.service;


public interface DiscountService {
    void applyDiscount(String code);
}
